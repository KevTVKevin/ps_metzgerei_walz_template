# ps_metzgerei_walz_template

dark-green: #306014

white: #ededed

black(hover): #2b2b2b

black(dropdown-hover): #484848

light-green: #c1c54a
